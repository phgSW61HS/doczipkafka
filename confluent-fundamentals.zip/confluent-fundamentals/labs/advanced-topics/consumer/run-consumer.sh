#! /bin/bash
docker container run -d --net advanced-topics_confluent sample-consumer:1.0
