#! /bin/bash
docker image build -t sample-consumer:1.0 .
