#! /bin/bash

docker container rm -f producer
docker-compose down -v
