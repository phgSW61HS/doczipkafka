Clone the `confluentinc/examples <https://github.com/confluentinc/examples>`__
GitHub repository and check out the
:litwithvars:`|release|-post` branch.

.. codewithvars:: bash

   git clone https://github.com/confluentinc/examples
   cd examples
   git checkout |release|-post
