Update your local configuration file (for example, at ``$HOME/.confluent/java.config``) with parameters to connect to |sr|.

- Template configuration file for |ccloud|

  .. literalinclude:: includes/configs/cloud/java-sr.config

- Template configuration file for local host

  .. literalinclude:: includes/configs/local/java-sr.config

