Update your local configuration file (for example, at ``$HOME/.confluent/springboot.config``) with parameters to connect to |sr|.

- Template configuration file for |ccloud|

  .. literalinclude:: includes/configs/cloud/springboot-sr.config

- Template configuration file for local host

  .. literalinclude:: includes/configs/local/springboot-sr.config

