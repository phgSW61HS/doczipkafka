Verify that your VPC can connect to the |ccloud| |sr| public internet endpoint.
