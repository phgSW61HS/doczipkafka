As described in the `Quick Start for Schema Management on Confluent Cloud <https://docs.confluent.io/cloud/current/get-started/schema-registry.html>`__ in the |ccloud| Console, enable
|ccloud| |sr| and create an API key and secret to connect
to it.

