Update your local configuration file (for example, at ``$HOME/.confluent/librdkafka.config``) with parameters to connect to |sr|.

- Template configuration file for |ccloud|

  .. literalinclude:: includes/configs/cloud/librdkafka-sr.config

- Template configuration file for local host

  .. literalinclude:: includes/configs/local/librdkafka-sr.config

