This example is similar to the previous example, except the value is formatted
as Avro and integrates with the |ccloud| |sr|. Before using |ccloud| |sr|, check
its `availability and limits <https://docs.confluent.io/cloud/current/overview.html>`__.\