import sbt._

object Dependencies {
}
