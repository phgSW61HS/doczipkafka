# Overview

Produce messages to and consume messages from a Kafka cluster using the [ Zendesk Ruby Client for Apache Kafka](https://github.com/zendesk/ruby-kafka).


# Documentation

You can find the documentation and instructions for running this Ruby example at [https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/ruby.html](https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/ruby.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.clients-ccloud)
