# Overview

Produce messages to and consume messages from a Kafka cluster using [kcat](https://github.com/edenhill/kcat).

# Documentation

You can find the documentation and instructions for running this kcat example at [https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/kcat.html](https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/kcat.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.clients-ccloud)
