# Overview
  
Produce messages to and consume messages from a Kafka cluster using Confluent REST Proxy.

# Documentation

You can find the documentation and instructions for running this Confluent REST Proxy example at [https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/rest-proxy.html](https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/rest-proxy.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.clients-ccloud)
