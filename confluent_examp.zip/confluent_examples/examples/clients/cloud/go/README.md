# Overview

Produce messages to and consume messages from a Kafka cluster using [Confluent Golang Client for Apache Kafka](https://github.com/confluentinc/confluent-kafka-go).

# Documentation

You can find the documentation and instructions for running this Go example at [https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/go.html](https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/go.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.clients-ccloud)
