# Overview

Produce messages to and consume messages from a Kafka cluster using Java interop from Clojure.

# Documentation

You can find the documentation and instructions for running this Clojure example at [https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/clojure.html](https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/clojure.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.clients-ccloud)
