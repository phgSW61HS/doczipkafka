# Overview

Produce messages to and consume messages from a Kafka cluster using the Apache bin commands.

# Documentation

You can find the documentation and instructions for running this Apache Kafka commands example at [https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/kafka-commands.html](https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/kafka-commands.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.clients-ccloud)
