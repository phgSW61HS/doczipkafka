# Overview

Produce messages to and consume messages from a Kafka cluster using the [rust-rdkafka client for Apache Kafka](https://github.com/fede1024/rust-rdkafka).


# Documentation

You can find the documentation and instructions for running this Rust example at [https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/rust.html](https://docs.confluent.io/platform/current/tutorials/examples/clients/docs/rust.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.clients-ccloud)
