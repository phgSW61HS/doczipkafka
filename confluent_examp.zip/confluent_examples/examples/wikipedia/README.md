![image](../images/confluent-logo-300-2.png)

# Notice

This example has been deprecated. In its place, we recommend [cp-demo](https://docs.confluent.io/platform/current/tutorials/cp-demo/docs/index.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.wikipedia) for a richer example of Confluent Platform.
