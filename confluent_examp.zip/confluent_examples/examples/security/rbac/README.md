![image](../../images/confluent-logo-300-2.png)

# Overview

These demos showcase the Role Based Access Control (RBAC) functionality in Confluent Platform. It is mostly for reference to see a workflow using the new RBAC feature across the services in Confluent Platform.

The documentation for running this demo is at [https://docs.confluent.io/platform/current/tutorials/examples/security/rbac/docs/index.html](https://docs.confluent.io/platform/current/tutorials/examples/security/rbac/docs/index.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.rbac)
