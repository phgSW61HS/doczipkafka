This example has moved to https://github.com/confluentinc/cp-all-in-one/
