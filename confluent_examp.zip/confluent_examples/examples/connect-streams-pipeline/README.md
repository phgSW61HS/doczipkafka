![image](../images/confluent-logo-300-2.png)

# Documentation

You can find the documentation and instructions for this "Pipelining with Kafka Connect and Kafka Streams" demo at [https://docs.confluent.io/platform/current/tutorials/examples/connect-streams-pipeline/docs/index.html](https://docs.confluent.io/platform/current/tutorials/examples/connect-streams-pipeline/docs/index.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.connect-streams-pipeline)

![image](docs/images/example_3.jpg)
