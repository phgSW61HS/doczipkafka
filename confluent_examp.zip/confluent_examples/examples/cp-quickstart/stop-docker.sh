#!/bin/bash

# Source library 
source ../utils/helper.sh

docker-compose down -v
