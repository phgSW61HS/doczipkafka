![image](../../images/confluent-logo-300-2.png)

# Confluent CLI

## Overview

You can use [Confluent CLI](https://docs.confluent.io/confluent-cli/current/install.html) to interact with your [Confluent Cloud](https://www.confluent.io/confluent-cloud/) cluster.


# Documentation

You can find the documentation and instructions for running this Confluent CLI example at [https://docs.confluent.io/platform/current/tutorials/examples/ccloud/docs/beginner-cloud.html](https://docs.confluent.io/platform/current/tutorials/examples/ccloud/docs/beginner-cloud.html?utm_source=github&utm_medium=demo&utm_campaign=ch.examples_type.community_content.beginner-cloud)
