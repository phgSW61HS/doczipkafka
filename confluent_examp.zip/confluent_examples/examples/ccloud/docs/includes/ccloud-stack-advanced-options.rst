This example uses :ref:`ccloud-stack` to automatically create a stack of fully managed services in |ccloud|.
By default, the ``ccloud-stack`` utility creates resources in a new |ccloud| environment in cloud provider ``aws`` in region ``us-west-2``.
If you want to reuse an existing |ccloud| environment, or if ``aws`` and ``us-west-2`` are not the target provider and region, you may configure :ref:`other ccloud-stack options <ccloud-stack-options>` before you run this example.
