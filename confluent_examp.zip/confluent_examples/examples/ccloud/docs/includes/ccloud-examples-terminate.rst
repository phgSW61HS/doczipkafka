Any |ccloud| example uses real |ccloud| resources.
After you are done running a |ccloud| example, manually verify that all |ccloud| resources are destroyed to avoid unexpected charges.
