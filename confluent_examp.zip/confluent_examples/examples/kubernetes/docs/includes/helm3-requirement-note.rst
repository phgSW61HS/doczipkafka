.. note:: As of Confluent Platform 5.4 Helm 3 is required.
