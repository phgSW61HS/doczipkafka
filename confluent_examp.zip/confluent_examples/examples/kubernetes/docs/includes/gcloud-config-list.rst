.. sourcecode:: bash

    gcloud config list --format 'value(core.project)'
