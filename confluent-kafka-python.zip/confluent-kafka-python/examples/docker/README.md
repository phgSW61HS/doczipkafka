# Example docker files

See the header of each Dockerfile in this directory for what is included.


## How to build

From the confluent-kafka-python source top directory:

    $ docker build -f examples/docker/Dockerfile.alpine .

